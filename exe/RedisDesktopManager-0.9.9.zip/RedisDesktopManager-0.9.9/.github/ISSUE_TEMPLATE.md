RDM Version: <br>
Environment (OS name and version): <br>
Redis Server Version: <br>

Steps to reproduce:

1. ...

2. ...

3. ...


Expected result: 

Actual Result: 
