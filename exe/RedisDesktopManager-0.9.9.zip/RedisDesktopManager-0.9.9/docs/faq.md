## Where stored config with connections?
**Windows** `C:\Users\%Your user%\.rdm\connections.json`

**OS X** `$HOME/Library/Preferences/rdm/connections.json`

**Linux** `$HOME/.rdm/connections.json`

## What info is sent to delelopers when app crashes
You can find answer here http://oops.redisdesktop.com/help/
