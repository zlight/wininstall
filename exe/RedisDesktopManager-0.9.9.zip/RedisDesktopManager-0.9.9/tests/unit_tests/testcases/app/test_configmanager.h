#pragma once
#include "basetestcase.h"

class TestConfigManager : public BaseTestCase
{
    Q_OBJECT
private slots:
    void testGetApplicationConfigPath();    
};

