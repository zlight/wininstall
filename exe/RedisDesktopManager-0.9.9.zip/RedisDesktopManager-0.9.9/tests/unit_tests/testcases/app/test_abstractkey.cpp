#include <QtCore>
#include <QTest>

#include "test_abstractkey.h"
#include "app/models/key-models/abstractkey.h"

void TestAbstractKey::testValueToBinary()
{
    // TODO:
}
