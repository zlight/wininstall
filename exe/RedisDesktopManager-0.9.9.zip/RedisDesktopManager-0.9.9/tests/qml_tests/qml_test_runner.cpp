#include <QtQuickTest/quicktest.h>
QUICK_TEST_MAIN(qml_tests)
